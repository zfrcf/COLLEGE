setblock ~-5 ~69 ~-3 minecraft:repeater[facing=north,delay=4]
setblock ~-3 ~71 ~-3 minecraft:repeater[facing=north,delay=4]
tellraw @a {"text":"Porte prête : levier de gauche = ouvrir, levier de droite = fermer.","color":"green"}
