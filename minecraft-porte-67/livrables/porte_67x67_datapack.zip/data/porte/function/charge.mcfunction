tellraw @a {"text":"[Porte] Datapack chargé. Place-toi au coin bas-gauche de l'ouverture et tape /function porte:construire","color":"aqua"}
